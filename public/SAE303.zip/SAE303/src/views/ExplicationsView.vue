<script setup>


</script>
    
<template>
    <div>
        <h2 class="">Explications</h2>
        <p class="pt-4 pb-5">
            Pour "conclure", les graphiques, les cartes et le filtre présent sur le site <br>
            permet d'avoir des renseignements utils aux utilisateurs quand ils font des recherches dans leur région. <br>
            Ils ont donc accêts à des informations utiles pour rechercher des festivals, musées, et cinémas, <br>
            pour organiser leurs futures découvertes culturels. <br> <br>
            Tous les graphiques sont très simple à comprendre, et à lire, <br>
            ce qui rend l'application simple et utilisable rapidement. <br> <br>  
        </p>
        <p class="pb-5">
            Ces données nous montres donc que la région à beaucoup de culture, <br>
            mais malheureusement peu être pas assez de diversification de culture. <br><br>
            Par exemple quand nous regardons les thèmes de festivals le plus faits dans la région, <br>
            nous pouvons remarquer que la musique et les spectacles vivant sont énormément fait, <br>
            mais les autres genres sont beaucoup moins fait et donc "oublier".
        </p>
            
    </div>
</template>