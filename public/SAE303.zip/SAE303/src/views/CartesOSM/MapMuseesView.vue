<script setup>
import MapMusees from '@/components/MapMusees.vue';


</script>
    
<template>
    <div>
        <h2 class="">Map Musées</h2>
        <p class="pt-4 pb-5">
            Sur cette page vous allez pouvoir rechercher tout les musées étant dans la Bourgogne-Franche-Comté ! <br>
            Il suffit de sélectioner un département et vous allez par la suite les voirs apparaître sur la carte. <br>
        </p>
        <MapMusees></MapMusees>
        
    </div>
</template>