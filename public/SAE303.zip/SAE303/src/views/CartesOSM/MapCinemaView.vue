<script setup>
import MapCinema from '@/components/MapCinema.vue';

</script>
    
<template>
    <div>
        <h2 class="">Map Cinema</h2>
        <p class="pt-4 pb-5">
            Sur cette page vous allez pouvoir rechercher tout les cinemas étant dans la Bourgogne-Franche-Comté ! <br>
            Il suffit de sélectioner un département et vous allez par la suite les voirs apparaître sur la carte. <br>
        </p>
       <MapCinema></MapCinema>
    </div>
</template>