<script setup>
import MapFestivals from '@/components/MapFestivals.vue';

</script>
    
<template>
    <div>
        <h2 class="">Map Festivals</h2>
        <p class="pt-4 pb-5">
            Sur cette page vous allez pouvoir rechercher tout les festivals étant dans la Bourgogne-Franche-Comté ! <br>
            Il suffit de sélectioner un département et vous allez par la suite les voirs apparaître sur la carte. <br>
        </p>
       <MapFestivals></MapFestivals>
    </div>
</template>