<template>
    <button class="bg-LightGreen/75 text-white border-MainGreen/50 border-2 font-raleway font-normal text-lg  py-1 px-10 rounded-xs">
          <slot/>
    </button>
  
  </template>