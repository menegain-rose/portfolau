<template>
    <svg width="1.5em" height="1.5em" viewBox="0 0 24 24"><path fill="#E9D200" strock="" d="m5.825 22l1.625-7.025L2 10.25l7.2-.625L12 3l2.8 6.625l7.2.625l-5.45 4.725L18.175 22L12 18.275Z"></path></svg>
</template>
  