<template>
    <svg width="1.2em" height="1.2em" viewBox="0 0 256 256"><path fill="#FCFCFB" d="M228 128a100 100 0 1 0-100 100a100.2 100.2 0 0 0 100-100Zm-96 91.9V148h28a4 4 0 0 0 0-8h-28v-28a20.1 20.1 0 0 1 20-20h16a4 4 0 0 0 0-8h-16a28.1 28.1 0 0 0-28 28v28H96a4 4 0 0 0 0 8h28v71.9a92 92 0 1 1 8 0Z"></path></svg>
  </template>
  
